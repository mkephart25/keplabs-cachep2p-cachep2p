=== Plugin Name ===
Contributors: mkephart25
Donate link: http://keplabs.me
Tags: comments, spam
Requires at least: 3.0.1
Tested up to: 4.6.1
Stable tag: 
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This plugin combines the extremely powerful CacheP2P and Wordpress. Simply install the plugin and you will have all of the pieces necessary to cache your Wordpress website based on the WebTorrent protocol written by the infamous Feross Aboukhadijeh.


== Description ==

This plugin combines the extremely powerful CacheP2P and Wordpress. Simply install the plugin and you will have all of the pieces necessary to cache your Wordpress website based on the WebTorrent protocol written by the infamous Feross Aboukhadijeh.

About CacheP2P:

99.99% made of Webtorrent
WebTorrent is what makes CacheP2P possible, (my public thanks Feross Aboukhadijeh for making WebTorrent). 

CacheP2P uses a slightly modified version of WebTorrent that allows hashes to be defined manually, CacheP2P needs this to create torrents from webpages and define it's Hashes based on each website's URLs, instead of the metadata. So that the URL is all that is needed to get a webpage's content from the Swarm. 

This removes a layer or security/verification from the torrent protocol (PEP9), but it is later added again by CacheP2P, together with the mechanism to define when any content in the cache has expired.

This plugin will be updated very often, check back daily for updates!



== Installation ==

This section describes how to install the plugin and get it working.

e.g.

1. Upload the plugin files to the `/wp-content/plugins/` directory, or install the plugin through the WordPress plugins screen directly.

2. Activate the plugin through the 'Plugins' screen in WordPress

3. Use the Settings->Plugin Name screen to configure the plugin

4. In your favorite FTP client or cpanel file manager, navigate to your website's root directory and continue on to the following directory /wp-content/plugins/keplabs-cachep2p/ - you will find a file called cachep2p.security.js please edit this file using the following instructions:



1. Using developer tools select the console tab(if using Chrome --> https://developer.chrome.com/devtools | if using FF --> https://addons.mozilla.org/en-US/firefox/addon/web-developer/). After installing developer tools, right click in the main body of your Wordpress website and select inspect element or developer tools (or simply Google How to do so --> http://lmgtfy.com/?q=how+to+use+chrome+developer+tools).

2. *Once in the console within chrome or FF developer tools, please look for the following --> [CacheP2P] this page's security hash: 6799676d21abe73a3bffb7941e5f2eb724528d5a (http://www.cachep2p.com/documentation.html)*

3. **Copy the hash code and paste it into the cachep2p.security.js file you are currently editing (referenced in step 4 above).

4. You will need to supply your url as an argument as well, see below for the proper syntax:

document.security_sha1 = {
  'http://www.example.com/': '3b3904d9b622eefede2309617133ad5e18a91928',
  'http://www.example.com/etc/etc/etc': 'e1ef63e31b940edf1c39d1b9656f9b9e23550e58',
  //'http://cachep2p.com/contact.html':       '299e74db8950463efa30fb5f30bc17d2fcb5b801',
}

5. Simply replace the hash you found in step 2 above for every page of your Wordpress website. Add each line step by step and watch out for any syntax errors. (I will be automating this within the next few days so please check back in a few days for a plugin update).**

6. Enjoy an extremely fast website, CDN's have no place to run now...

7. If you'd like to test the funstionality out, make sure you open an ingognito tab within Google Chrome or a private tab within FF and open the page you want to simulate caching for, then on another device or machine click on the various links you registered in the cachep2p.security.js file and watch in the developer console for detailed information regarding the CacheP2P process! It's super fast so make sure you check back soon for more updates.

http://keplabs.me


== Frequently Asked Questions ==

= What if I see the hash code duplicate error?  =

Make sure you check your cachep2p.security.js file and confirm the syntax is correct

= What if I read through the entire Readme and still have problems? =

Make sure the file permissions on the file cachep2p.security.js are correct. You can google linux file permissions for more...


== Screenshots ==


== Changelog ==

= 1.0 =

== Arbitrary section ==


== A brief Markdown Example ==


Here's a link to [WordPress](http://wordpress.org/ "Your favorite software") and one to [Markdown's Syntax Documentation][markdown syntax].
Titles are optional, naturally.

[markdown syntax]: http://daringfireball.net/projects/markdown/syntax
            "Markdown is what the parser uses to process much of the readme file"

Markdown uses email style notation for blockquotes and I've been told:
> Asterisks for *emphasis*. Double it up  for **strong**.

`<?php code(); // goes in backticks ?>`