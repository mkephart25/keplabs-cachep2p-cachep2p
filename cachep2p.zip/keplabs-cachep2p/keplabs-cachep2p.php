<?php
/**
 * Plugin Name: CacheP2P Wordpress
 * Plugin URI: http://keplabs.me
 * Description: This plugin adds basic CacheP2P functionality to your Wordpress website.
 * Version: 1.0.0
 * Author: Michael Kephart
 * Author URI: http://keplabs.me
 * License: GPL2
 */
defined( 'ABSPATH' ) or die( 'No script kiddies please!' );

add_action( 'wp_footer', 'my_cachep2p_tags' );
function my_cachep2p_tags() {

echo '<script src="' . plugins_url( 'cachep2p.min.js', __FILE__ ) . '" > </script>';
echo '<script src="' . plugins_url( 'cachep2p.security.js', __FILE__ ) . '" > </script>';
echo '<script src="' . plugins_url( 'init.js', __FILE__ ) . '" > </script>';

}