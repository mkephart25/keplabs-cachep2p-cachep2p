var cachep2p = new CacheP2P()

cachep2p.on('ready', function(){
  console.log('This page has been cached!')
})
cachep2p.on('message', console.log)
cachep2p.on('alert', console.log)
cachep2p.on('success', console.log)