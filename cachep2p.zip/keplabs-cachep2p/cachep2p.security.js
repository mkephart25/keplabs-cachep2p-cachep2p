document.security_sha1 = {
  'http://www.example.com/': '3b3904d9b622eefede2309617133ad5e18a91928',
  'http://www.example.com/etc/etc/etc': 'e1ef63e31b940edf1c39d1b9656f9b9e23550e58',
  //'http://cachep2p.com/contact.html':       '299e74db8950463efa30fb5f30bc17d2fcb5b801',
}